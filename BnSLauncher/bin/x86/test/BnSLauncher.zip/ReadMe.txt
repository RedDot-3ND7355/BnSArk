Blade and Soul Na/EU Custom Launcher
Coded: Arisu Miyako
LynMarket: http://lynmarket.enjin.com

Install by extracting to anywhere. The launcher will automatically find Client.exe
If the launcher can not find Client.exe, place the launcher into the BnS install folder with Client.exe
Ex. D:\NCSOFT\BnS\bin

Version 1.0
+ Supports NA and EU clients
+ Shows the ping for NA and EU every 5 seconds
+ Supports English, French and German
++ If the NA client is installed, only Enlgish works.

Todo:
+ Option to disable GameGuard
+ Mod/Restore Management